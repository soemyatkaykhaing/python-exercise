import logging
from flask import Flask, render_template, request, jsonify
from datetime import datetime, timezone

app = Flask(__name__)
logging.basicConfig(filename='app.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def calculate_delivery_fee(cart_value, delivery_distance, num_items, delivery_time):
    # Rule 1: Small order surcharge
    if cart_value/100 < 10:
        surcharge = 10 - (cart_value/100)
    else:
        surcharge = 0
    logging.info('Returning surcharge: %s', surcharge)
    # Rule 2: Base delivery fee for the first 1000 meters
    base_fee = 2

    # Additional fee for every 500 meters beyond the first 1000 meters
    
    additional_fee = max(1, (delivery_distance - 1000) // 500)
    if delivery_distance%500 > 0:
        additional_fee+=1
    logging.info('Returning additional_fee: %s', additional_fee)

    # Calculate total distance fee
    distance_fee = base_fee + additional_fee

    # Rule 3: Surcharge for the number of items
    item_surcharge = max(0, (num_items - 4) * 0.5)
    logging.info('Returning item_surcharge: %s', item_surcharge)

    # Bulk fee for more than 12 items
    bulk_fee = 1.20 if num_items > 12 else 0

    # Rule 4: The delivery fee can never be more than 15€
    total_fee = min(15, surcharge + distance_fee + item_surcharge + bulk_fee)
    logging.info('Returning total_fee: %s', total_fee)

    # Rule 5: Free delivery for cart value equal or more than 200€
    if cart_value/100 >= 200:
        total_fee = 0

    # Rule 6: Friday rush (3 - 7 PM UTC)
    if delivery_time.weekday() == 4:  # Friday
        if 15 <= delivery_time.hour < 19:
            total_fee *= 1.2
            total_fee = min(15, total_fee)  # Ensure it does not exceed 15€

    return round(total_fee, 3)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate_fee', methods=['POST'])
def calculate_fee():
    data = request.get_json()
    logging.info('Incoming POST request with data: %s', data)

    # Extract data from the request
    cart_value = float(data['cart_value'])
    delivery_distance = int(data['delivery_distance'])
    num_items = int(data['num_items'])
    delivery_time_str = data['delivery_time']
    date_format = '%Y-%m-%dT%H:%M'

    # Convert delivery time string to datetime object
    delivery_time = datetime.strptime(delivery_time_str, date_format).replace(tzinfo=timezone.utc)

    # Calculate the delivery fee using the previously defined function
    total_fee = calculate_delivery_fee(cart_value, delivery_distance, num_items, delivery_time)
    logging.info('Returning JSON response: %s', total_fee)

    # Return the result in JSON format
    return jsonify({'total_fee': total_fee})

if __name__ == '__main__':
    app.run(debug=True, port=5000)

